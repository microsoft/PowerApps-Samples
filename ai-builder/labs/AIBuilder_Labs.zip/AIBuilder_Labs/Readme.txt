This AIBuilder labs walks through object detection, binary classification, text classification, form processing & business card reader scenarios.

Visit [https://docs.microsoft.com/en-us/ai-builder/overview] to learn more about these scenarios and AIBuilder.

Please follow the steps below to set up the environment to use AIBuilder Labs 

For Binary Classification, Text Classification and Object Detection scenarios you need sample data in CDS.

Manual data set up

Part 1 :Import AIBuilderLabSolution_1_0_0_0 solution to the CDS environment.
This creates 3 CDS entities - Object Detection Product , Health Feedback and Online Shopping Intent 

Part 2 : Upload data to the entities created in part 1 
- Binary classification : Follow the instructions here[https://docs.microsoft.com/en-us/ai-builder/binary-classification-data-prep] to upload the Online Shopping Intent data.
- Text Classification : Go to Lab Data/Text Classification folder within the lab files. Then upload data from pai_healthcare_feedbacks. Instructions here [https://docs.microsoft.com/en-us/ai-builder/before-you-build-text-classification-model]
- Object Detection : Go to Lab Data/ObjectDetection folder.Then upload data from aib_objectdetectionproducts. Please follow the same instructions as above for data upload.


Automated lab Environment & data set up 
Follow the instructions in the Automated Lab Environment folder to build and run the tool which will create a trial CDS organization with the data already uploaded.


For form processing, business card reader, and object detection labs, you need images/pdfs which are available in the Lab Images folder 